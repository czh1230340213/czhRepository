Hello大家好，欢迎和我一起学习Rabbitmq实战课程!
rabbitmq-api 为基础api与高级特性源码
rabbitmq-spring 为整合springamqp框架源码
rabbitmq-springboot-producer & rabbitmq-springboot-consumer 为整合springboot框架源码
rabbitmq-springcloudstream-producer & rabbitmq-springcloudstream-consumer 为整合spring cloud stream源码