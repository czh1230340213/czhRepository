package com.bfxy.rabbitmq.quickstart;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.QueueingConsumer;
import com.rabbitmq.client.QueueingConsumer.Delivery;

public class Consumer {

	public static void main(String[] args) throws Exception {
		
		//1 创建一个ConnectionFactory, 并进行配置
		ConnectionFactory connectionFactory = new ConnectionFactory();
		connectionFactory.setHost("localhost");
		connectionFactory.setPort(5672);
		connectionFactory.setVirtualHost("/");
//		connectionFactory.setUsername("guest");
//		connectionFactory.setPassword("guest");
		//2 通过连接工厂创建连接
		Connection connection = connectionFactory.newConnection();
		
		//3 通过connection创建一个Channel
		Channel channel = connection.createChannel();
		
		//4 声明（创建）一个队列 queueName	持久化(重启)	独占方式(只有改channel才能消费)	与exchange没有绑定则删除	扩展参数
		String queueName = "test001";
		channel.queueDeclare(queueName, true, false, false, null);
		
		//5 创建消费者	建立在channel上的
		QueueingConsumer queueingConsumer = new QueueingConsumer(channel);
		
		//6 设置Channel	消费那个队列	是否自动签收(c->Broker)	消费者对象
		channel.basicConsume(queueName, true, queueingConsumer);
		
		while(true){
			//7 获取消息 消息,channel进行封装
			//可以设置阻塞时间
			Delivery delivery = queueingConsumer.nextDelivery();
			String msg = new String(delivery.getBody());
			System.out.println("消费端: " + msg);
			//Envelope envelope = delivery.getEnvelope();
		}
		
	}
}
